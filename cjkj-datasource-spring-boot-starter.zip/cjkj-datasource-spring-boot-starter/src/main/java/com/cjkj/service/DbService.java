package com.cjkj.service;

import com.cjkj.entity.dbone.SysUserOne;
import com.cjkj.entity.dbtwo.SysTwo;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: service类
 **/
public interface DbService {

    SysTwo selectTwo(long id);

    SysUserOne selectUser(long id);

}
