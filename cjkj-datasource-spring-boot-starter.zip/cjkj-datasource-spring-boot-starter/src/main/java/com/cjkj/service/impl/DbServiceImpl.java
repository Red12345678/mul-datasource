package com.cjkj.service.impl;

import com.cjkj.enums.DataSourceType;
import com.cjkj.dao.SysTwoDao;
import com.cjkj.dao.SysUserOneDao;
import com.cjkj.entity.dbone.SysUserOne;
import com.cjkj.entity.dbtwo.SysTwo;
import com.cjkj.service.DbService;
import com.cjkj.system.annotation.DB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: service实现类
 **/
@Service
public class DbServiceImpl implements DbService {

    @Autowired
    private SysUserOneDao sysUserOneDao;

    @Autowired
    private SysTwoDao sysTwoDao;

    @Override
    public SysUserOne selectUser(long id) {
        return sysUserOneDao.selectById(id);
    }

    @DB(DataSourceType.DB1)
    @Override
    public SysTwo selectTwo(long id) {
        return sysTwoDao.selectById(id);
    }

}
