package com.cjkj.controller;

import com.cjkj.service.DbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: 测试Controller类
 **/
@RestController
public class OpenController {
    @Autowired
    private DbService dbService;

    @GetMapping("/open2")
    public Object login() {
        return dbService.selectTwo(1);
    }

    @GetMapping("/open")
    public Object login1() {
        return dbService.selectUser(1);
    }

}
