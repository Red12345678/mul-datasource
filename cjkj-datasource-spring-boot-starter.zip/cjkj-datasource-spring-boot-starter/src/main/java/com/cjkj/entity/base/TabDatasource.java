package com.cjkj.entity.base;

import lombok.Data;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: 数据源对象
 **/
@Data
public class TabDatasource {

    /**
     * 连接数据库服务地址
     */
    private String jdbcUrl;

    /**
     * 链接数据库用户名
     */
    private String username;

    /**
     * 链接数据库用密码
     */
    private String password;

    /**
     * 链接数据库驱动
     */
    private String driverClassName;

    /**
     * 当前数据源是否可用标识
     */
    private boolean enabled;

    /**
     * 切换数据源key，最好通过下，可以这么命名：DB1，DB2，DB3 .....
     */
    private String toDataSourceKey;

}
