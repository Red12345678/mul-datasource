package com.cjkj.entity.dbone;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: db1 表对象
 **/
@Setter
@Getter
@ToString
@TableName("sys_user_one")
public class SysUserOne implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * user_id
     */
    @TableId
    private Integer userId;

    /**
     * user_name
     */
    private String userName;

    public SysUserOne() {
    }

}
