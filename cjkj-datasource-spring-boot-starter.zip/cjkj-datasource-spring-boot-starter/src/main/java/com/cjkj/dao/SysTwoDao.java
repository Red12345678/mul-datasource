package com.cjkj.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cjkj.entity.dbtwo.SysTwo;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: dao测试类
 **/
public interface SysTwoDao extends BaseMapper<SysTwo> {

}

