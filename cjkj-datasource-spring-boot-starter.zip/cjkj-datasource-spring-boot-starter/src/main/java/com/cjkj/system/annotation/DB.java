package com.cjkj.system.annotation;

import com.cjkj.enums.DataSourceType;

import java.lang.annotation.*;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: 注解
 **/
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public @interface DB {
    /**
     * 切换数据源名称
     */
    DataSourceType value() default DataSourceType.MASTER;
}
