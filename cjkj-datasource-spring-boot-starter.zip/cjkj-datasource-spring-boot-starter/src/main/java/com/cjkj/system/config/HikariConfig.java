package com.cjkj.system.config;

import com.cjkj.enums.DataSourceType;
import com.cjkj.entity.base.TabDatasource;
import com.cjkj.system.datasource.DbProperties;
import com.cjkj.system.datasource.DynamicDataSource;
import com.cjkj.system.datasource.HikariProperties;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: Hikari多数据源配置
 **/
@Configuration
public class HikariConfig {

    @Bean(name = "masterDataSourceDb")
    @ConfigurationProperties("dbs.master-db")
    public DataSource dataSourceDb1(HikariProperties properties) {
        HikariDataSource dataSource = DataSourceBuilder.create().type(HikariDataSource.class).build();
        return properties.dataSource(dataSource);
    }

    /**
     * <ol>实例化动态数据源Bean</ol>
     * <li>判断子数据源必要信息是否为空，为空动态数据源中只包含主数据源</li>
     * <li>过滤出enabled=true也就是生效的数据源</li>
     * <li>Map封装子数据源实例，结构为{key: 指定的key, value: 子数据源实例}</li>
     * <li>将主数据源和所有的子数据源封装到动态数据源中并返回</li>
     *
     * @param masterDataSourceDb
     * @param dbProperties
     * @param hikariProperties
     * @return
     */
    @Bean(name = "dynamicDataSource")
    @Primary
    public DynamicDataSource dataSource(DataSource masterDataSourceDb,
                                        DbProperties dbProperties, HikariProperties hikariProperties) {
        Map<Object, Object> targetDataSources = new HashMap<>();
        List<TabDatasource> baseDbInfoList = dbProperties.getBaseDbInfoList();
        // 如果子数据源必要信息为空，动态数据源中只包含主数据源
        if (baseDbInfoList == null || baseDbInfoList.size() < 1) {
            return new DynamicDataSource(masterDataSourceDb, targetDataSources);
        }
        // 过滤出enabled=true也就是生效的数据源
        baseDbInfoList = baseDbInfoList.stream().filter(t -> t.isEnabled()).collect(Collectors.toList());
        // Map封装子数据源实例，结构为{key: 指定的key, value: 子数据源实例}
        baseDbInfoList.forEach(e -> {
            HikariDataSource subDataSource = DataSourceBuilder.create().type(HikariDataSource.class).build();
            subDataSource = hikariProperties.dataSource(subDataSource);
            subDataSource.setJdbcUrl(e.getJdbcUrl());
            subDataSource.setUsername(e.getUsername());
            subDataSource.setPassword(e.getPassword());
            subDataSource.setDriverClassName(e.getDriverClassName());
            targetDataSources.put(e.getToDataSourceKey(), subDataSource);
        });
        targetDataSources.put(DataSourceType.MASTER.name(), masterDataSourceDb);
        return new DynamicDataSource(masterDataSourceDb, targetDataSources);
    }

    /**
     * 实例化事务管理器
     *
     * @param dynamicDataSource
     * @return
     */
    @Bean
    @Primary
    public PlatformTransactionManager dynamicDataSourceTransactionManager(DynamicDataSource dynamicDataSource) {
        return new DataSourceTransactionManager(dynamicDataSource);
    }
}
