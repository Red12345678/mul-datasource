package com.cjkj.enums;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: 枚举类
 **/
public enum DataSourceType {

    /**主数据源*/
    MASTER,
    /**子数据源1*/
    DB1
}
